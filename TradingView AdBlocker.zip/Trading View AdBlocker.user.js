// ==UserScript==
// @name         Trading View AdBlocker
// @namespace    http://tampermonkey.net/
// @version      2025-04-29
// @description  It will not block any ads instead it just hides it
// @author       Uday Sheth (Github : Sheth007)
// @match        https://in.tradingview.com/chart/x2Ni7DNc/?symbol=*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tradingview.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    alert('AdBlock acivated');
    document.getElementById("toastGroup-JUpQSPBo").style.display = "none";
    document.getElementById("itemInnerInner-JUpQSPBo").style.display = "none";
    document.getElementById("charting-ad").style.display = "none";
})();